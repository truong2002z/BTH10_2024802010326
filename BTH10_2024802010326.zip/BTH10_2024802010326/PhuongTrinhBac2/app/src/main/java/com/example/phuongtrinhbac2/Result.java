package com.example.phuongtrinhbac2;

public class Result {
    private float result;

    public Result(float result) {
        this.result = result;
    }

    public float getResult() {
        return result;
    }

    public void setResult(float result) {
        this.result = result;
    }
}
